import { vi } from 'vitest';

const qrcode = {
  toDataURL: vi.fn(),
};

export default qrcode;