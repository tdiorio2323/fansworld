import { vi } from 'vitest';

export const toast = {
  success: vi.fn(),
  error: vi.fn(),
};