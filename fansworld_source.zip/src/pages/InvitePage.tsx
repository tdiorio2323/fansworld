import { InviteRedemption } from "@/components/InviteRedemption";

export default function InvitePage() {
  return <InviteRedemption />;
}